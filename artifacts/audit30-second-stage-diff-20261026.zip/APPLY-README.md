# audit30 second-stage diff overlay

Contains full replacement files under the existing project-relative paths, plus validation reports and the handoff note. Extract at the root of the matching `irena-reborn` source checkout. Back up the checkout first.

After extraction, run `npm test`, `npm run check`, and `npm run build`. The archive intentionally omits generated `dist/index.html` and the giant `irena-play.html`; build recreates the deployable site. Extraction does not publish a Sites version.
